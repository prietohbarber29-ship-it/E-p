package com.epbarbershop.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URLEncoder
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

private val Gold = Color(0xFFD5AD5B)
private val Ink = Color(0xFF111111)
private val Panel = Color(0xFF1C1C1C)
private val Muted = Color(0xFFB8B8B8)

data class Appointment(val name: String, val phone: String, val service: String, val date: String, val time: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BarberApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BarberApp() {
    val context = LocalContext.current
    val services = listOf("Servicio completo", "Corte normal", "Cerquillo", "Cejas", "Facial", "Afeitada", "Niños", "Diseños")
    val prices = mapOf("Servicio completo" to 700, "Corte normal" to 500, "Cerquillo" to 300, "Cejas" to 100, "Facial" to 250, "Afeitada" to 200, "Niños" to 300, "Diseños" to 0)
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var time by remember { mutableStateOf("10:00") }
    var service by remember { mutableStateOf(services[1]) }
    var expanded by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("") }
    val appointments = remember { mutableStateListOf<Appointment>() }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, onPrimary = Ink, background = Ink, surface = Panel,
        onSurface = Color.White, secondary = Gold
    )) {
        Scaffold(containerColor = Ink) { pad ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(top = 22.dp, bottom = 28.dp)
            ) {
                item {
                    Text("E&P BARBER SHOP", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    Text("Agenda y reservas", color = Muted, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("Citas", appointments.size.toString(), Modifier.weight(1f))
                        StatCard("Hoy", appointments.count { it.date == LocalDate.now().toString() }.toString(), Modifier.weight(1f))
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Nueva cita", color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(name, { name = it }, label = { Text("Nombre del cliente") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(phone, { phone = it }, label = { Text("WhatsApp (ej. 18095551234)") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                                OutlinedTextField(service, {}, readOnly = true, label = { Text("Servicio") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                    services.forEach { s -> DropdownMenuItem(text = { Text("$s — " + if (prices[s] == 0) "Precio aparte" else "RD$ ${prices[s]}") }, onClick = { service = s; expanded = false }) }
                                }
                            }
                            OutlinedTextField(date, { date = it }, label = { Text("Fecha (AAAA-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(time, { time = it }, label = { Text("Hora (24 h, ej. 14:30)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Button(
                                onClick = {
                                    if (name.isBlank() || phone.filter { it.isDigit() }.length < 10 || runCatching { LocalDate.parse(date); LocalTime.parse(time) }.isFailure) {
                                        notice = "Revisa nombre, teléfono, fecha y hora."
                                    } else {
                                        val overlap = appointments.any { it.date == date && it.time == time }
                                        if (overlap) notice = "Ya existe una cita a esa hora en esta agenda."
                                        else {
                                            appointments.add(Appointment(name.trim(), phone.filter { it.isDigit() }, service, date, time))
                                            notice = "Cita agregada en esta sesión. Envíale la confirmación por WhatsApp."
                                            name = ""; phone = ""
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
                            ) { Text("Guardar cita", fontWeight = FontWeight.Bold) }
                            if (notice.isNotBlank()) Text(notice, color = Gold, fontSize = 13.sp)
                        }
                    }
                }
                item { Text("Agenda de esta sesión", color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold) }
                if (appointments.isEmpty()) item { Text("Todavía no hay citas. Agrega una arriba para probar.", color = Muted) }
                items(appointments.sortedWith(compareBy<Appointment> { it.date }.thenBy { it.time })) { a ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(a.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("${a.service} • ${a.date} • ${a.time}", color = Muted)
                            Text("Tel. +${a.phone}", color = Muted, fontSize = 13.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    val msg = "Hola ${a.name}, te recordamos tu cita en E&P Barber Shop: ${a.service}, el ${a.date} a las ${a.time}. ¡Te esperamos!"
                                    val url = "https://wa.me/${a.phone}?text=" + Uri.encode(msg)
                                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                                }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) { Text("WhatsApp") }
                                OutlinedButton(onClick = { appointments.remove(a); notice = "Cita eliminada de esta sesión." }) { Text("Eliminar", color = Color.White) }
                            }
                        }
                    }
                }
                item {
                    Text("Importante: esta versión es una demostración local. Las citas no se comparten entre celulares ni se guardan al cerrar la app. WhatsApp abre un mensaje preparado; el envío automático requiere un servidor y WhatsApp Business Platform.", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
    }
}
