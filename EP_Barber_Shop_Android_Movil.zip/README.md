# E&P Barber Shop — proyecto inicial Android

Este ZIP contiene un **proyecto fuente inicial** para abrir en Android Studio. No es todavía un APK compilado ni un sistema de producción.

## Incluye en la app de prueba
- Interfaz negra y dorada para E&P Barber Shop.
- Formulario para registrar citas y seleccionar servicios/precios.
- Agenda en memoria durante la sesión abierta.
- Validación básica de fecha, hora y teléfono.
- Botón WhatsApp que prepara un mensaje para que el usuario lo revise y lo envíe.

## Limitaciones importantes
- Los datos se guardan solo en memoria: al cerrar la app se pierden.
- La agenda es local a un solo dispositivo; no sincroniza reservas de clientes y barbero.
- La comprobación de choques de horario es básica y solo revisa esta sesión.
- El botón WhatsApp **no envía automáticamente** ni ejecuta recordatorios programados.

## Requisitos para generar una APK de prueba
1. Instala Android Studio en una computadora.
2. Abre la carpeta `EP_Barber_Shop_APK_Starter` como proyecto.
3. Espera a que Gradle sincronice y descarga los componentes de Android SDK que solicite.
4. Usa **Build > Build APK(s)**.
5. Android Studio mostrará la ubicación del APK de depuración, normalmente `app/build/outputs/apk/debug/app-debug.apk`.
6. Para instalar en un teléfono, transfiere el APK y autoriza la instalación de esa fuente. Para distribución formal, genera una APK/AAB firmada desde **Build > Generate Signed Bundle / APK**.

El proyecto puede requerir ajustes de versiones de Gradle/SDK según la versión instalada de Android Studio. Este entorno no compiló ni verificó la APK.

## Para una versión real con clientes y barbero
Hace falta una base de datos compartida y autenticación, por ejemplo Firebase:
- Firebase Authentication para cuentas de barbero/administrador.
- Cloud Firestore para clientes, servicios y citas.
- Reglas de seguridad para que cada rol pueda acceder solo a lo permitido.
- Transacciones/validación en servidor para impedir que dos clientes reserven el mismo turno.

## Recordatorios automáticos de WhatsApp
El teléfono no debe guardar tokens secretos ni llamar directamente a la API de WhatsApp. La configuración recomendada es:
1. Crear/usar una cuenta Meta Business y configurar WhatsApp Business Platform (Cloud API), incluyendo un número válido.
2. Verificar la empresa y registrar el número según los requisitos de Meta.
3. Preparar plantillas de mensajes de recordatorio y obtener aprobación cuando corresponda. Los mensajes iniciados por el negocio fuera de la ventana de atención al cliente normalmente requieren plantillas aprobadas.
4. Guardar el token de acceso de forma segura en un backend, nunca dentro de la APK.
5. Cuando se crea una cita, guardar fecha/hora en UTC y la zona horaria `America/Santo_Domingo`.
6. Programar tareas en el backend (por ejemplo, Cloud Functions + Cloud Scheduler/Task Queue) para enviar recordatorios 24 horas antes y, opcionalmente, 2 horas antes.
7. Registrar resultado, reintentos, citas canceladas y consentimiento del cliente para recibir mensajes.
8. Probar primero con destinatarios autorizados y confirmar el costo vigente de Meta/proveedor antes de producción.

## Mensaje de ejemplo
“Hola {{1}}, te recordamos tu cita en E&P Barber Shop el {{2}} a las {{3}} para {{4}}. Si necesitas cambiarla, responde a este mensaje. ¡Te esperamos!”

## Próximo desarrollo recomendado
- Persistencia y sincronización Firebase.
- Vista de reservas para clientes y panel privado del barbero.
- Disponibilidad por estación/barbero, duración de servicios y bloqueo de horarios.
- Confirmar, reprogramar y cancelar.
- Función de backend para recordatorios automáticos WhatsApp Cloud API.
