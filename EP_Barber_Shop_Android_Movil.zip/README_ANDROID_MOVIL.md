# E&P Barber Shop — preparado para trabajar desde Android

Este proyecto incluye código fuente Android y una acción de GitHub para compilar una APK sin tener computadora. **No es una APK compilada todavía.**

## Método recomendado desde tu móvil Android

### 1. Crea una cuenta en GitHub
Abre https://github.com en Chrome y crea una cuenta o inicia sesión.

### 2. Sube el proyecto
1. Descarga y descomprime `EP_Barber_Shop_Android_Movil.zip` con la aplicación Archivos de tu móvil.
2. En GitHub, crea un repositorio nuevo llamado `ep-barber-shop` y déjalo como **Private** si quieres mantener el código privado.
3. Entra al repositorio, pulsa **Add file → Upload files** y sube los archivos y carpetas descomprimidos. Asegúrate de que `.github/workflows/build-apk.yml` también quede subido.
4. Pulsa **Commit changes**.

> Si GitHub móvil no muestra la carpeta oculta `.github`, abre GitHub en Chrome y activa “Sitio para ordenador”, o crea la carpeta y archivo desde el editor web. La ruta debe ser `.github/workflows/build-apk.yml`.

### 3. Compila la APK desde GitHub
1. En tu repositorio, abre la pestaña **Actions**.
2. Elige **Build E&P Barber Shop APK**.
3. Pulsa **Run workflow** si no se inició automáticamente tras subir el código.
4. Espera a que el trabajo termine con una marca verde.
5. Abre la ejecución terminada y descarga el artefacto **EP-Barber-Shop-debug-APK**.
6. Descomprime ese archivo ZIP para obtener `app-debug.apk`.
7. Toca la APK en tu teléfono para instalarla. Android puede pedirte permiso para instalar aplicaciones desde Chrome o Archivos; actívalo solo para la aplicación desde la que descargaste el archivo y desactívalo después si quieres.

La compilación en la nube requiere conexión a Internet. GitHub puede cambiar la ubicación de botones; consulta su documentación de Actions si el menú varía.

## Qué incluye esta primera versión
- Interfaz negra y dorada.
- Formulario para registrar una cita.
- Servicios y precios de ejemplo.
- Agenda temporal en el dispositivo.
- Botón que abre WhatsApp con un texto preparado para revisar y enviar.

## Limitaciones que debes conocer
- Los datos de citas de esta demostración se guardan solo en memoria y se pierden al cerrar la aplicación.
- La agenda no está sincronizada entre teléfonos. No la uses todavía como agenda de producción.
- El botón WhatsApp no envía mensajes automáticamente.
- Esta APK de depuración no está firmada para distribución pública.

## Para convertirla en una aplicación real
Se debe añadir un backend compartido, autenticación, base de datos y reglas para evitar dobles reservas. Para recordatorios automáticos se necesita:
1. Cuenta Meta Business y WhatsApp Business Platform/Cloud API con un número configurado.
2. Plantillas de recordatorio aprobadas cuando corresponda y consentimiento de los clientes.
3. Un servidor seguro con tareas programadas, por ejemplo Firebase Cloud Functions + Cloud Scheduler/Tasks.
4. Guardar el token de WhatsApp en el servidor, nunca dentro de la APK.
5. Enviar recordatorios, por ejemplo, 24 horas antes y 2 horas antes; registrar resultados y no enviar si la cita fue cancelada.
6. Configurar la zona horaria `America/Santo_Domingo`.

## Precios de ejemplo incluidos
Servicio completo RD$700, corte normal RD$500, cerquillo RD$300, cejas RD$100, facial RD$250, afeitada RD$200, niños RD$300 y diseños con precio aparte. Puedes cambiar los importes en `MainActivity.kt`.
